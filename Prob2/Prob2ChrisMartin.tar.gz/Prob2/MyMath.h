#ifndef MY_MATH_H
#define MY_MATH_H
 
class MyMath
{
public:
MyMath() { };
double factorial (int a, int stop=1);
double binom(int n, int k);

};

 
#endif