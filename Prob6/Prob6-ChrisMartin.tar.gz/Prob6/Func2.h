#ifndef FUNC_2_H
#define FUNC_2_H
 
class Func2
{
	private:
	
	public:
	Func2(){};
	Doub operator() (double p);

};

 
#endif