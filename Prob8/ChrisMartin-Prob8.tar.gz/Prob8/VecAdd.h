#ifndef VEC_ADD_H
#define VEC_ADD_H
 
VecDoub VecAdd(VecDoub A, VecDoub B, bool subtract = false);

 
#endif