#ifndef FUNCT_I_H
#define FUNCT_I_H
 
class FunctI
{

public:
	FunctI() {};
	Doub operator() (double x);
	

};

 
#endif