#ifndef FUNC_H
#define FUNC_H
 
class Func
{
	private:
	
	public:
	Func(){};
	Doub operator() (VecDoub_I &x);

};

 
#endif