#ifndef RANDOM_H
#define RANDOM_H
 
void RandList(double array[], int length);
 
#endif