#ifndef TRANSPOSE_H
#define TRANSPOSE_H
 
MatDoub Transpose(MatDoub A);

 
#endif