#ifndef EVOLVE_H
#define EVOLVE_H
 
void Evolve(int nMasses, double Mass[], double position[][3], double velocity[][3], double DeltaT);
 
#endif