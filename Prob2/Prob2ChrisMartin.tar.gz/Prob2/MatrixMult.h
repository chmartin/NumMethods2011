#ifndef MATRIX_MULT_H
#define MATRIX_MULT_H
 
MatDoub MatrixMult(MatDoub A, MatDoub B);

 
#endif