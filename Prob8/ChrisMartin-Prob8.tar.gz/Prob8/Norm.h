#ifndef NORM_H
#define NORM_H
 
VecDoub Norm(VecDoub B);

 
#endif