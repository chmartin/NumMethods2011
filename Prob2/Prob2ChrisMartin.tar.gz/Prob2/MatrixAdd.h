#ifndef MATRIX_ADD_H
#define MATRIX_ADD_H
 
MatDoub MatrixAdd(MatDoub A, MatDoub B, bool subtract = false);

 
#endif