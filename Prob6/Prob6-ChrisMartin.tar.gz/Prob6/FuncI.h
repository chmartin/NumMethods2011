#ifndef FUNC_I_H
#define FUNC_I_H
 
class FuncI
{
	private:
	double p;
	
	public:
	FuncI(double pp);
	Doub operator() (double x);

};

 
#endif