#ifndef FUNC_3_H
#define FUNC_3_H
 
class Func3
{
	private:
	
	public:
	Func3(){};
	Doub operator() (double r);

};

 
#endif