#ifndef MATRIX_SCALE_H
#define MATRIX_SCALE_H
 
MatDoub Scale(double scale, MatDoub A);

 
#endif