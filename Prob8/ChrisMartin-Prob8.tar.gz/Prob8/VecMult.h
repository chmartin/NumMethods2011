#ifndef VEC_MULT_H
#define VEC_MULT_H
 
double VecMult(VecDoub A, VecDoub B);

 
#endif