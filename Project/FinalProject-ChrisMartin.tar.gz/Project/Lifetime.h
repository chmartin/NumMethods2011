#ifndef LIFETIME_H
#define LIFETIME_H
 
double Lifetime(double tau);

 
#endif